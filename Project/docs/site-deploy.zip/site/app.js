async function loadData() {
  const kpis = document.getElementById('kpis');
  const companyName = document.getElementById('companyName');
  try {
    const resp = await fetch('./assets/sample_results.json');
    const data = await resp.json();
    const s = data.summary;
    companyName.textContent = s.company;

    const rows = [
      ['市值', `${s.market_cap_b}B`],
      ['AV', `${s.av_b}B`],
      ['EPV', `${s.epv_b}B`],
      ['FV', `${s.fv_b}B`],
      ['总价值', `${s.total_value_b}B`],
      ['WACC', `${s.wacc_pct}%`],
      ['ROIC', `${s.roic_pct}%`],
      ['安全边际', `${s.margin_of_safety_pct}%`]
    ];

    kpis.innerHTML = rows
      .map(([label, value]) => `<div class="kpi"><div class="label">${label}</div><div class="value">${value}</div></div>`)
      .join('');
  } catch (e) {
    kpis.innerHTML = '<div class="card">无法加载结果文件，请确认 assets/sample_results.json 存在。</div>';
  }
}

loadData();
